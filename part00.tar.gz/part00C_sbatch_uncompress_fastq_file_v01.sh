#!/bin/bash
#SBATCH --account=hologenomics         # Project Account
#SBATCH --partition=hologenomics 
#SBATCH --mem 512M
#SBATCH -c 1
#SBATCH -t 3:00:00
#SBATCH -J 00C_uncomp_fastq
#SBATCH -o stdout_00C_uncomp_fastq.txt
#SBATCH -e stderr_00C_uncomp_fastq.txt

#load modules required
module purge

#start the bash script that iterates over compressed gz files


RWzipF="X204SC22012323-Z01-F001.zip"
# define input directory with novogen file 
INDR1="00A_raw_compressed_novogenefile"
# define output directory where the  unzipped novogene files are to be placed 
OUDR1="00B_raw_compressed_fastq.gz_files"
# define output directory where the unzipped 'fastq.gz' files are to be placed 
OUDR2="00C_uncompressed_fastq.gz_files"


#put present working directory in a variable
WD=$(pwd)
#REMDIR="/groups/hologenomics/phq599/data/EBIODIV_2021jun25"
#WD="${REMDIR}"
REMDIR="${WD}"
#define inpout directory
INDIR01="00B_raw_compressed_fastq.gz_files/X204SC22012323-Z01-F001/raw_data"
INDIR02=$(echo ""${REMDIR}"/"${INDIR01}"")


rm -rf "${OUDR2}" 
mkdir "${OUDR2}"

# change dire to the dir that holds the fastq files
cd "$INDIR02"
# make a list that holds the names of the fastq files
LSSMPL=$(ls | awk 'BEGIN { FS = "_" } ; {print $1"_"$2}' | sed '/Rawdata_Readme.pdf/q' | sed '$d')

#make the list of samples an array you can iterate over
declare -a SMPLARRAY=($LSSMPL)
	
#change back to the working dir
cd "$WD"

#iterate over samples
for smp in ${SMPLARRAY[@]}
do
PATH02=$(echo ""${INDIR02}"/"${smp}"")
cd "${PATH02}"
for f in *.fq.gz
	do
		cp $f $WD/"${OUDR2}"/.
	done
done
